def main():
    print('Hi from mobile_robotics.')


if __name__ == '__main__':
    main()
